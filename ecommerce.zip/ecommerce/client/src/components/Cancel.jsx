import React from 'react';

const Cancel = () => {
    return (
        <div className="flex flex-col items-center justify-center h-screen bg-red-50">
            <div className="bg-white shadow-lg rounded-lg p-8">
                <h2 className="text-4xl font-bold text-red-600 mb-4">Payment Canceled</h2>
                <p className="text-lg text-gray-700 mb-6">Your payment has been canceled. Please try again.</p>
                <a
                    href="/cart"
                    className="px-6 py-3 bg-red-500 text-white rounded-full font-semibold hover:bg-red-600 transition duration-300"
                >
                    Go Back to Cart
                </a>
            </div>
        </div>
    );
};

export default Cancel;

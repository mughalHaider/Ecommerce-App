import React from 'react'
// import twitter from '../assets/footer/x-twitter.svg'

const Footer = () => {
    return (
        <div className='flex justify-center md:h-[60vh] items-center bg-[#363636] text-white w-full px-[20px] md:px-[100px]'>
            <div className='flex flex-col md:flex-row justify-between items-center w-full'>
                <div className='w-[100%] md:w-[30%] flex-col items-center md:items-start flex justify-center gap-5'>
                    <h1 className='text-white text-[48px] font-semibold font-dancing'>Fashion</h1>
                    <p className='text-center md:text-start text-[#CDD5DF]'>123 Wanderer Street Bvd., Any City,
                    Any State, Any Country Name</p>
                    <p className='text-[#CDD5DF]'>( +123 ) 456 7890</p>
                </div>
                <div className='flex md:flex-row items-center md:items-start flex-col gap-[30px] md:gap-10 my-10 md:my-0'>
                    <div className='flex flex-col gap-7 items-center md:items-start'>
                        <h1 className='text-[16px] font-bold'>About Us</h1>
                        <div className='flex flex-col justify-center items-center gap-3 md:items-start md:gap-0'>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>History </p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Chat</p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Menu</p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Reviews</p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Career</p>
                        </div>
                    </div>
                    <div className='flex flex-col gap-7 items-center md:items-start'>
                        <h1 className='text-[16px] font-bold'>Customer</h1>
                        <div className='flex flex-col justify-center items-center gap-3 md:items-start md:gap-0'>
                            <p className='text-[16px] font-normal text-[#CDD5DF]'>Order </p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Reservation</p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Subscription</p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Gift Cards</p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>User Policy</p>
                        </div>
                    </div>
                    <div className='flex flex-col gap-7 items-center md:items-start'>
                        <h1 className='text-[16px] font-bold'>Contact</h1>
                        <div className='flex flex-col justify-center items-center gap-3 md:items-start md:gap-0'>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Phone </p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Email</p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Socials</p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Location Map</p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Message Form</p>
                        </div>
                    </div>
                    <div className='flex flex-col gap-7 items-center md:items-start'>
                        <h1 className='text-[16px] font-bold'>Support</h1>
                        <div className='flex flex-col justify-center items-center gap-3 md:items-start md:gap-0'>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>FAQ </p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>On Site Rules</p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Privacy Policy</p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Refund Policy</p>
                            <p className=' text-[16px] font-normal text-[#CDD5DF]'>Terms and Conditions</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Footer
import React from 'react'
import { IoSearch } from "react-icons/io5";
import { FaShoppingCart } from "react-icons/fa";
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { GiHamburgerMenu } from "react-icons/gi";

const Navbar = () => {
    const location = useLocation()
    const navigate = useNavigate()
    const cartItems = useSelector(state => state.cart.items);
    const handleNavigate = () => {
        navigate('/cart')
    }


    return (
        <div className='font-poppins flex justify-between items-center md:px-10 px-3 shadow-md'>
            <div className="logo md:text-[48px] text-[36px] font-dancing font-bold relative group hover:text-pink-900 transition-all">
                Fashion
                <span className="absolute inset-0 bg-pink-200 opacity-0 rounded-full transition-all duration-300 transform scale-50 group-hover:opacity-60 group-hover:scale-110"></span>
            </div>

            <div>
                <nav>
                    <ul className="md:flex hidden lg:gap-6 gap-2.5">
                        <li className="group relative">
                            <Link to="/" className={`font-medium text-black ${location.pathname === '/' ? 'active' : ''}`}>Home</Link>
                            <span className={`absolute left-0 bottom-[-3px] h-[4px] bg-pink-400 transition-all duration-300 ${location.pathname === '/' ? 'w-full' : 'w-0 group-hover:w-full'}`}></span>
                        </li>
                        {/* <li className="group relative">
                            <Link to="/womens" className={`font-medium text-black ${location.pathname === '/womens' ? 'active' : ''}`}>Womens</Link>
                            <span className={`absolute left-0 bottom-[-3px] h-[4px] bg-pink-400 transition-all duration-300 ${location.pathname === '/womens' ? 'w-full' : 'w-0 group-hover:w-full'}`}></span>
                        </li>
                        <li className="group relative">
                            <Link to="/mens" className={`font-medium text-black ${location.pathname === '/mens' ? 'active' : ''}`}>Mens</Link>
                            <span className={`absolute left-0 bottom-[-3px] h-[4px] bg-pink-400 transition-all duration-300 ${location.pathname === '/mens' ? 'w-full' : 'w-0 group-hover:w-full'}`}></span>
                        </li> */}
                        <li className="group relative">
                            <Link to="/shop" className={`font-medium text-black ${location.pathname === '/shop' ? 'active' : ''}`}>Shop</Link>
                            <span className={`absolute left-0 bottom-[-3px] h-[4px] bg-pink-400 transition-all duration-300 ${location.pathname === '/shop' ? 'w-full' : 'w-0 group-hover:w-full'}`}></span>
                        </li>
                        {/* <li className="group relative">
                            <Link to="/pages" className={`font-medium text-black ${location.pathname === '/pages' ? 'active' : ''}`}>Pages</Link>
                            <span className={`absolute left-0 bottom-[-3px] h-[4px] bg-pink-400 transition-all duration-300 ${location.pathname === '/pages' ? 'w-full' : 'w-0 group-hover:w-full'}`}></span>
                        </li> */}
                        <li className="group relative">
                            <Link to="/blog" className={`font-medium text-black ${location.pathname === '/blog' ? 'active' : ''}`}>Blog</Link>
                            <span className={`absolute left-0 bottom-[-3px] h-[4px] bg-pink-400 transition-all duration-300 ${location.pathname === '/blog' ? 'w-full' : 'w-0 group-hover:w-full'}`}></span>
                        </li>
                        <li className="group relative">
                            <Link to="/contacts" className={`font-medium text-black ${location.pathname === '/contacts' ? 'active' : ''}`}>Contacts</Link>
                            <span className={`absolute left-0 bottom-[-3px] h-[4px] bg-pink-400 transition-all duration-300 ${location.pathname === '/contacts' ? 'w-full' : 'w-0 group-hover:w-full'}`}></span>
                        </li>
                    </ul>
                </nav>
            </div>

            <div className='flex items-center md:gap-5 gap-3'>
                <div className='md:text-[16px] text-[12px]'>Login / Register</div>
                <div className='flex items-center md:gap-3 gap-2'>
                    <div className='relative'>
                        <FaShoppingCart onClick={handleNavigate} size={20} className='hover:cursor-pointer' />
                        {/* Conditional rendering for the red dot */}
                        {cartItems.length > 0 && (
                            <span className='absolute top-0 right-0 h-2 w-2 rounded-full bg-red-600' />
                        )}
                    </div>

                    <IoSearch size={20} className='hover:cursor-pointer' />
                    <GiHamburgerMenu size={25} className='hover:cursor-pointer' />
                </div>
            </div>
        </div>
    )
}

export default Navbar
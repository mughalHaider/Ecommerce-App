import React from 'react';

const Success = () => {
    return (
        <div className="flex flex-col items-center justify-center h-screen bg-green-50">
            <div className="bg-white shadow-lg rounded-lg p-8">
                <h2 className="text-4xl font-bold text-green-600 mb-4">Payment Successful!</h2>
                <p className="text-lg text-gray-700 mb-6">Thank you for your purchase. Your payment has been processed successfully.</p>
                <a
                    href="/shop"
                    className="px-6 py-3 bg-green-500 text-white rounded-full font-semibold hover:bg-green-600 transition duration-300"
                >
                    Continue Shopping
                </a>
            </div>
        </div>
    );
};

export default Success;

import React from 'react'
import mainModel from '../../assets/mainModel-removebg-preview.png'
import model1 from '../../assets/girl120-removebg-preview.png'
import model2 from '../../assets/mens_fashion-removebg-preview.png'
import model4 from '../../assets/kidsimage-removebg-preview.png'
import model5 from '../../assets/images-removebg-preview.png'
import { useNavigate } from 'react-router-dom'

const Banner = () => {

    const navigate = useNavigate()
    const handleCart = () => {
      navigate('/shop')
    }
    

    return (
        <div className='mt-2 flex gap-2'>
            <div className='lg:w-[50%] w-[100%] flex md:flex-row flex-col justify-center items-center bg-[#FBDCEB] ml-0 lg:ml-1.5 lg:pb-0 pb-10'>
                <div className='md:w-[50%] md:mt-0 mt-10 w-[80%] pl-10 flex flex-col gap-2'>
                    <h1 className='text-[40px] font-dancing font-semibold'>Women's Fashion</h1>
                    <div className='w-[100%] flex flex-col gap-1'><p className='w-[100%] text-sm font-normal'>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Facere, suscipit.</p>
                        <p onClick={handleCart} className="cursor-pointer relative inline-block text-lg font-semibold text-gray-800 lg:hover:after:w-1/3 hover:after:w-1/5 after:transition-all after:duration-300 after:ease-in-out after:absolute after:left-0 after:bottom-[-5px] after:h-[4px] after:bg-blue-600 after:w-1/6">
                            Shop Now
                        </p>
                    </div>
                </div>
                <div className='md:w-[60%] w-[80%]'>
                    <img src={mainModel} className='' alt="" />
                </div>
            </div>
            <div className='w-[50%] lg:flex hidden flex-wrap gap-2 '>
                <div className='bg-[#C0CEE2] flex justify-between pl-5 items-center w-[49%]'>
                    <div>
                        <h1 className='text-lg font-semibold font-poppins'>Men's Fashion</h1>
                        <div>
                            <p className='text-[11px] font-normal'>200+ Items</p>
                            <p onClick={handleCart} className="cursor-pointer relative inline-block text-md font-semibold text-gray-800 hover:after:w-1/2 after:transition-all after:duration-300 after:ease-in-out after:absolute after:left-0 after:bottom-[-5px] after:h-[4px] after:bg-blue-600 after:w-1/6">
                                Shop Now
                            </p>
                        </div>
                    </div>
                    <div ><img src={model2} height={150} width={150} alt="" /></div>
                </div>

                <div className='bg-red-300 lg:flex hidden justify-between items-center w-[49%] pl-5'>
                    <div>
                        <h1 className='text-lg font-semibold font-poppins'>Clothing</h1>
                        <div>
                            <p className='text-[11px] font-normal'>200+ Items</p>
                            <p onClick={handleCart} className="cursor-pointer relative inline-block text-md font-semibold text-gray-800 hover:after:w-1/2 after:transition-all after:duration-300 after:ease-in-out after:absolute after:left-0 after:bottom-[-5px] after:h-[4px] after:bg-blue-600 after:w-1/6">
                                Shop Now
                            </p>
                        </div>
                    </div>
                    <div><img src={model5} height={190} width={185} alt="" /></div>
                </div>

                <div className='bg-[#FBE2DC] lg:flex hidden justify-between items-center pl-5 w-[49%]'>
                    <div>
                        <h1 className='text-lg font-semibold font-poppins'>Kid's Fashion</h1>
                        <div>
                            <p className='text-[11px] font-normal'>17+ Items</p>
                            <p onClick={handleCart} className="cursor-pointer relative inline-block text-md font-semibold text-gray-800 hover:after:w-1/2 after:transition-all after:duration-300 after:ease-in-out after:absolute after:left-0 after:bottom-[-5px] after:h-[4px] after:bg-blue-600 after:w-1/6">
                                Shop Now
                            </p>
                        </div>
                    </div>
                    <div className=''> <img src={model4} height={180} width={170} alt="" /></div>
                </div>

                <div className='bg-[#79F3E1] lg:flex hidden justify-between items-center pl-5 w-[49%]'>
                    <div>
                        <h1 className='text-lg font-semibold font-poppins'>Girls Accessories</h1>
                        <div>
                            <p className='text-[11px] font-normal'>300+ Items</p>
                            <p onClick={handleCart} className="cursor-pointer relative inline-block text-md font-semibold text-gray-800 hover:after:w-1/2 after:transition-all after:duration-300 after:ease-in-out after:absolute after:left-0 after:bottom-[-5px] after:h-[4px] after:bg-blue-600 after:w-1/6">
                                Shop Now
                            </p>
                        </div>
                    </div>
                    <div className=''><img src={model1} height={200} width={180} alt="" /></div>
                </div>
            </div>
        </div>
    )
}

export default Banner
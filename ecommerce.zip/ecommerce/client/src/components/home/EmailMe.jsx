import React from 'react'

const EmailMe = () => {
  return (
    <div className='flex justify-center items-center h-[50vh] '>
        <div className='w-[80%] flex md:flex-row flex-col md:gap-0 gap-5 justify-center md:justify-between py-3 md:px-10 px-2 md:pr-20 pr-0 items-center bg-[#f1f1f1]'>
            <div className='w-[100%] md:w-[60%] flex justify-center md:justify-start items-center md:items-start flex-col gap-2'>
                <h1 className='lg:text-[50px] md:text-[35px] text-[22px] font-semibold '>10% off Discount Coupons</h1>
                <p>Subscribe to get 10% off on all purchase</p>
            </div>
            <div><button className='rounded-xl border border-black-300 bg-black lg:px-16 md:px-10 px-5 md:py-3 py-1 text-white lg:text-lg text-[18px] font-normal'>Email Me</button></div>
        </div>
    </div>
  )
}

export default EmailMe
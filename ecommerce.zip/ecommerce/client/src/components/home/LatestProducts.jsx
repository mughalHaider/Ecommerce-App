import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { IoSearch } from 'react-icons/io5';
import shoe1 from '../../assets/oip-removebg-preview.png';
import shoe2 from '../../assets/OIP__1_-removebg-preview.png';
import shoe3 from '../../assets/OIP__2_-removebg-preview.png';
import shoe4 from '../../assets/OIP__3_-removebg-preview.png';

const LatestProducts = () => {

    const navigate = useNavigate();
    const handleNavigate = () => {
        navigate('/shop');
    };

    return (
        <div className='mt-10 my-20'>
            <div className='flex justify-between items-center mx-10'>
                <h1 className='text-[30px] font-poppins font-medium'>Latest Products</h1>
                <Link to='/shop'><p className='text-[18px] font-poppins font-medium'>View All</p></Link>
            </div>
            <div className='flex flex-wrap justify-center my-1'>
                {/* Product 1 */}
                <div
                    className="relative bg-white w-[290px] cursor-pointer something py-4 rounded-xl hover:shadow-2xl shadow-xl transition-all m-4 flex gap-3 flex-col justify-center items-center"
                >
                    <div className="image h-[80%] rounded-lg w-[90%] bg-[#F8BD59] flex justify-center items-center">
                        <img src={shoe1} className='aspect-[3/2] object-contain' height={450} width={450} alt="Shoe 1" />
                    </div>
                    <div className='flex w-[100%] flex-row justify-between px-4 items-center'>
                        <h2 className="text-lg font-bold">Latest Shoe Brand</h2>
                        <p className="text-sm font-bold">$400</p>
                    </div>
                    <button
                        className="absolute bottom-4 left-[45%] transform -translate-x-1/2 translate-y-10 opacity-0 bg-green-600 text-white p-3 rounded-full transition-all duration-300 hover:bg-green-700"
                        onClick={handleNavigate}
                    >
                        <IoSearch size={20} />
                    </button>
                </div>

                {/* Product 2 */}
                <div
                    className="relative bg-white w-[290px] cursor-pointer something py-4 rounded-xl hover:shadow-2xl shadow-xl transition-all m-4 flex gap-3 flex-col justify-center items-center"
                >
                    <div className="image h-[80%] rounded-lg w-[90%] bg-[#8dc0e9] flex justify-center items-center">
                        <img src={shoe2} className='aspect-[3/2] object-contain' height={450} width={450} alt="Shoe 2" />
                    </div>
                    <div className='flex w-[100%] flex-row justify-between px-4 items-center'>
                        <h2 className="text-lg font-bold">Latest Shoe Brand</h2>
                        <p className="text-sm font-bold">$400</p>
                    </div>
                    <button
                        className="absolute bottom-4 left-[45%] transform -translate-x-1/2 translate-y-10 opacity-0 bg-green-600 text-white p-3 rounded-full transition-all duration-300 hover:bg-green-700"
                        onClick={handleNavigate}
                    >
                        <IoSearch size={20} />
                    </button>
                </div>

                {/* Product 3 (fixed button positioning) */}
                <div
                    className="relative bg-white w-[290px] cursor-pointer something py-4 rounded-xl hover:shadow-2xl shadow-xl transition-all m-4 flex gap-3 flex-col justify-center items-center"
                >
                    <div className="image h-[80%] rounded-lg w-[90%] bg-[#ccff4c] flex justify-center items-center">
                        <img src={shoe3} className='aspect-[3/2] object-contain' height={450} width={450} alt="Shoe 3" />
                    </div>
                    <div className='flex w-[100%] flex-row justify-between px-4 items-center'>
                        <h2 className="text-lg font-bold">Latest Shoe Brand</h2>
                        <p className="text-sm font-bold">$400</p>
                    </div>
                    <button
                        className="absolute bottom-4 left-[45%] transform -translate-x-1/2 translate-y-10 opacity-0 bg-green-600 text-white p-3 rounded-full transition-all duration-300 hover:bg-green-700"
                        onClick={handleNavigate}
                    >
                        <IoSearch size={20} />
                    </button>
                </div>

                {/* Product 4 */}
                <div
                    className="relative bg-white w-[290px] cursor-pointer something py-4 rounded-xl hover:shadow-2xl shadow-xl transition-all m-4 flex gap-3 flex-col justify-center items-center"
                >
                    <div className="image h-[80%] rounded-lg w-[90%] bg-[#dedfe2] flex justify-center items-center">
                        <img src={shoe4} className='aspect-[3/2] object-contain' height={450} width={450} alt="Shoe 4" />
                    </div>
                    <div className='flex w-[100%] flex-row justify-between px-4 items-center'>
                        <h2 className="text-lg font-bold">Latest Shoe Brand</h2>
                        <p className="text-sm font-bold">$400</p>
                    </div>
                    <button
                        className="absolute bottom-4 left-[45%] transform -translate-x-1/2 translate-y-10 opacity-0 bg-green-600 text-white p-3 rounded-full transition-all duration-300 hover:bg-green-700"
                        onClick={handleNavigate}
                    >
                        <IoSearch size={20} />
                    </button>
                </div>

                {/* Hover effect to reveal Add to Cart icon */}
                <style jsx>{`
                    .something:hover button {
                        transform: translate(100px, -50px);
                        opacity: 1;
                    }
                `}</style>
            </div>
        </div>
    );
};

export default LatestProducts;

import React from 'react'
import { Navigation, Pagination, Scrollbar, A11y , Autoplay} from 'swiper/modules';

import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/scrollbar';
import product1 from '../../assets/product1.jpg'
import product2 from '../../assets/product2.jpg'
import product3 from '../../assets/product3.jpg'
import product4 from '../../assets/product4.jpg'
import shoe1 from '../../assets/shoe1.jpg'
import shoe2 from '../../assets/shoe2.jpg'
import '../../index.css'




const NewlyArrived = () => {
    return (
        <div>
            <div className='ml-10 text-[30px] font-poppins font-semibold'><h1>Newly Arrived Brands</h1></div>
            <Swiper
                // install Swiper modules
                modules={[Navigation, Pagination, Scrollbar, A11y, Autoplay]}
                spaceBetween={50}
                slidesPerView={3}
                navigation
                autoplay={{ delay: 2000 }}
                speed={800}
                loop={true}
                pagination={{ clickable: true }}
                onSwiper={(swiper) => console.log(swiper)}
                onSlideChange={() => console.log('slide change')}
                className='mx-10 mb-8 py-12'
            >

                <SwiperSlide>
                    <div className=' flex lg:flex-row flex-col shadow-lg rounded-lg p-3 gap-3'>
                        <div className=' w-[30%]'><img className='rounded-lg' src={product4} alt="" /></div>
                        <div className='w-[70%] flex flex-col justify-center'>
                            <p className='text-gray-600'>Amber Jar</p>
                            <h1 className='text-gray-600 text-[18px] font-medium font-poppins'>Honey Best Nector you wish to get</h1>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide>
                    <div className=' flex lg:flex-row flex-col shadow-lg rounded-lg p-3 gap-3'>
                        <div className='w-[30%]'><img className='rounded-lg' src={product3} alt="" /></div>
                        <div className='w-[70%] flex flex-col justify-center'>
                            <p className='text-gray-600'>Amber Jar</p>
                            <h1 className='text-gray-600 text-[18px] font-medium font-poppins'>Honey Best Nector you wish to get</h1>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide>
                    <div className=' flex lg:flex-row flex-col shadow-xl rounded-lg p-3 gap-3'>
                        <div className='w-[30%]'><img className='rounded-lg' src={product2} alt="" /></div>
                        <div className='w-[70%] flex flex-col justify-center'>
                            <p className='text-gray-600'>Amber Jar</p>
                            <h1 className='text-gray-600 text-[18px] font-medium font-poppins'>Honey Best Nector you wish to get</h1>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide>
                    <div className=' flex lg:flex-row flex-col shadow-lg rounded-lg p-3 gap-3'>
                        <div className='w-[30%]'><img className='rounded-lg' src={product1} alt="" /></div>
                        <div className='w-[70%] flex flex-col justify-center'>
                            <p className='text-gray-600'>Amber Jar</p>
                            <h1 className='text-gray-600 text-[18px] font-medium font-poppins'>Honey Best Nector you wish to get</h1>
                        </div>
                    </div>
                </SwiperSlide>
            </Swiper>
            <div className='w-[100%] flex gap-5 justify-center my-20 lg:flex-row flex-wrap'>
                <div className='something md:w-[48%] w-[90%]'><img className='rounded-xl' src={shoe1} alt="" /></div>
                <div className='something md:w-[48%] w-[90%]'><img className='rounded-xl' src={shoe2}  alt="" /></div>
            </div>

        </div>
    );
}

export default NewlyArrived
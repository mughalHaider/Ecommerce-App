import React, { useState, useEffect } from 'react';
import { GoStarFill } from "react-icons/go";
import { useDispatch } from 'react-redux';
import { addToCart } from '../../counter/cartSlice';
import { toast } from 'react-toastify';
import '../../index.css'

const Products = () => {
    const [products, setProducts] = useState([]);
    const [filteredProducts, setFilteredProducts] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [isTransitioning, setIsTransitioning] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false); // Modal state
    const [selectedProduct, setSelectedProduct] = useState(null); // Selected product for modal

    const dispatch = useDispatch(); // Redux dispatch

    const fetchData = async () => {
        try {
            const response = await fetch("https://fakestoreapi.com/products");
            const result = await response.json();
            console.log(result);
            setProducts(result);
            setFilteredProducts(result); // Show all products initially
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const nameShorten = (name, maxLength) => {
        if (name.length > maxLength) {
            return name.substring(0, maxLength) + " ..."
        }
        return name;
    };

    const filterByCategory = (category) => {
        setIsTransitioning(true); // Start the transition
        setTimeout(() => {
            if (category === 'All') {
                setFilteredProducts(products);
            } else {
                const filtered = products.filter(product => product.category === category);
                setFilteredProducts(filtered);
            }
            setSelectedCategory(category);
            setIsTransitioning(false);
        }, 300);
    };

    // Handle add to cart
    const handleAddToCart = (product) => {
        dispatch(addToCart(product)); // Dispatch addToCart action with product data
        // toast.success(`${product.title} added to cart!`);
    };

    // Handle modal opening
    const handleOpenModal = (product) => {
        setSelectedProduct(product); // Set the selected product
        setIsModalOpen(true); // Open the modal
    };

    // Handle modal closing
    const handleCloseModal = () => {
        setIsModalOpen(false); // Close the modal
    };

    return (
        <div className='mb-10'>
            <div className='mx-32 flex md:flex-row flex-col justify-between items-center mb-5'>
                <h1 className='md:text-[30px] sm:text-[18px]  font-semibold font-poppins'>Shop Now</h1>
                <ul className='flex md:gap-7 gap-4'>
                    {['All', "men's clothing", "women's clothing", 'electronics', 'jewelery'].map(category => (
                        <li
                            key={category}
                            className={`cursor-pointer relative ${selectedCategory === category ? 'text-blue-600 font-bold' : ''}`}
                            onClick={() => filterByCategory(category)}
                        >
                            {category === "men's clothing" ? "Mens" : category === "women's clothing" ? "Womens" : category}
                            <span
                                className={`absolute left-0 bottom-0 w-full h-[2px] bg-blue-600 transition-all duration-300 transform scale-x-0 ${selectedCategory === category ? 'scale-x-100' : 'hover:scale-x-100'}`}
                            />
                        </li>
                    ))}
                </ul>
            </div>
            <div>
                {filteredProducts.length > 0 ? (
                    <div className={`flex flex-wrap justify-center gap-4 transition-opacity duration-300 ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}>
                        {filteredProducts.map((product) => (
                            <div 
                                key={product.id}
                                className="bg-white w-[270px] cursor-pointer something py-10 rounded-xl hover:shadow-2xl shadow-xl transition-all m-4 flex gap-8 flex-col justify-center items-center"
                                onClick={() => handleOpenModal(product)} // Open modal on product click
                            >
                                <div className="image h-[70%] rounded-lg w-[90%] bg-[#f1f1f1] flex justify-center items-center">
                                    <img src={product.image} className='aspect-[3/2] object-contain mix-blend-darken' height={200} width={200} alt="" />
                                </div>
                                <div className='flex h-[30%] flex-col gap-3 justify-center items-center'>
                                    <div className='flex flex-col justify-center items-center'>
                                        <h2 className="text-lg font-bold">{nameShorten(product.title, 20)}</h2>
                                        <div className='flex gap-5 justify-center items-center'>
                                            <p className="text-sm text-gray-600">Quantity: 1</p>
                                            <p className='flex justify-center items-center gap-2'><GoStarFill size={15} className='text-[#ffc43f]' /> 4.5</p>
                                        </div>
                                        <p className="text-sm font-bold">Price: ${product.price}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className='ml-20'>No products available in this category.</p>
                )}
            </div>

            {/* Modal */}
            {isModalOpen && selectedProduct && (
                <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                    <div className="bg-white w-[400px] p-5 rounded-lg shadow-lg">
                        <button onClick={handleCloseModal} className="text-right text-red-500">Close</button>
                        <div className="flex flex-col items-center">
                            <img src={selectedProduct.image} alt={selectedProduct.title} className="w-40 h-40 object-contain" />
                            <h2 className="text-lg font-bold mt-4">{selectedProduct.title}</h2>
                            <p className="text-sm text-gray-600 mt-2">{selectedProduct.description}</p>
                            <p className="text-sm text-gray-600 mt-2">Quantity: 1</p>
                            <p className="text-sm font-bold mt-2">Price: ${selectedProduct.price}</p>
                            <button
                                onClick={() => handleAddToCart(selectedProduct)} // Add to cart button inside modal
                                className='mt-4 hover:bg-transparent hover:text-green-600 transition-all border rounded-md hover:border-green-600 bg-green-600 text-white px-5 py-2'
                            >
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Products;




































// import React, { useState, useEffect } from 'react';
// import { GoStarFill } from "react-icons/go";
// import { useDispatch } from 'react-redux';
// import { addToCart } from '../../counter/cartSlice';
// import { toast } from 'react-toastify';
// const Products = () => {
//     const [products, setProducts] = useState([]);
//     const [filteredProducts, setFilteredProducts] = useState([]);
//     const [selectedCategory, setSelectedCategory] = useState('All');
//     const [isTransitioning, setIsTransitioning] = useState(false);
    
//     const dispatch = useDispatch(); // Redux dispatch

//     const fetchData = async () => {
//         try {
//             const response = await fetch("https://fakestoreapi.com/products");
//             const result = await response.json();
//             console.log(result)
//             setProducts(result);
//             setFilteredProducts(result); // Show all products initially
//         } catch (error) {
//             console.error('Error fetching data:', error);
//         }
//     };

//     useEffect(() => {
//         fetchData();
//     }, []);

//     const nameShorten = (name, maxLength) => {
//         if (name.length > maxLength) {
//             return name.substring(0, maxLength);
//         }
//         return name;
//     };

//     const filterByCategory = (category) => {
//         setIsTransitioning(true); // Start the transition
//         setTimeout(() => {
//             if (category === 'All') {
//                 setFilteredProducts(products);
//             } else {
//                 const filtered = products.filter(product => product.category === category);
//                 setFilteredProducts(filtered);
//             }
//             setSelectedCategory(category);
//             setIsTransitioning(false); 
//         }, 300); 
//     };

//     // Handle add to cart
//     const handleAddToCart = (product) => {
        
//         dispatch(addToCart(product)); // Dispatch addToCart action with product data
//     };

//     return (
//         <div className='mb-10'>
//             <div className='mx-32 flex md:flex-row flex-col justify-between items-center mb-5'>
//                 <h1 className='md:text-[30px] sm:text-[18px]  font-semibold font-poppins'>Shop Now</h1>
//                 <ul className='flex md:gap-7 gap-4'>
//                     {['All', "men's clothing", "women's clothing", 'electronics', 'jewelery'].map(category => (
//                         <li
//                             key={category}
//                             className={`cursor-pointer relative ${selectedCategory === category ? 'text-blue-600 font-bold' : ''}`}
//                             onClick={() => filterByCategory(category)}
//                         >
//                             {category === "men's clothing" ? "Mens" : category === "women's clothing" ? "Womens" : category}
//                             <span
//                                 className={`absolute left-0 bottom-0 w-full h-[2px] bg-blue-600 transition-all duration-300 transform scale-x-0 ${selectedCategory === category ? 'scale-x-100' : 'hover:scale-x-100'
//                                     }`}
//                             />
//                         </li>
//                     ))}
//                 </ul>
//             </div>
//             <div>
//                 {filteredProducts.length > 0 ? (
//                     <div className={`flex flex-wrap justify-center gap-4 transition-opacity duration-300 ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}>
//                         {filteredProducts.map((product) => (
//                             <div key={product.id} className="something bg-white w-[270px] py-10 rounded-xl hover:shadow-2xl shadow-xl transition-all m-4 flex gap-8 flex-col justify-center items-center">
//                                 <div className="image h-[70%] rounded-lg w-[90%] bg-[#f1f1f1] flex justify-center items-center">
//                                     <img src={product.image} className='aspect-[3/2] object-contain mix-blend-darken' height={200} width={200} alt="" />
//                                 </div>
//                                 <div className='flex h-[30%] flex-col gap-3 justify-center items-center'>
//                                     <div className='flex flex-col justify-center items-center'>
//                                         <h2 className="text-lg font-bold">{nameShorten(product.title, 20)}</h2>
//                                         <div className='flex gap-5 justify-center items-center'>
//                                             <p className="text-sm text-gray-600">Quantity: 1</p>
//                                             <p className='flex justify-center items-center gap-2'><GoStarFill size={15} className='text-[#ffc43f]' /> 4.5</p>
//                                         </div>
//                                         <p className="text-sm font-bold">Price: ${product.price}</p>
//                                     </div>
//                                     <div>
//                                         <button
//                                             onClick={() => handleAddToCart(product)} // Add to cart button click handler
                                          
//                                             className='hover:bg-transparent hover:text-green-600 transition-all border rounded-md hover:border-green-600 bg-green-600 text-white px-5 py-2'
//                                         >
//                                             Add to Cart
//                                         </button>
//                                     </div>
//                                 </div>
//                             </div>
//                         ))}
//                     </div>
//                 ) : (
//                     <p className='ml-20'>No products available in this category.</p>
//                 )}
//             </div>
//         </div>
//     );
// };

// export default Products;

















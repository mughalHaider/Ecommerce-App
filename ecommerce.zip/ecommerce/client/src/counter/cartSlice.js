import { createSlice } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
// Load cart items from localStorage, or set an empty array if nothing is saved
const initialCartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

const initialState = {
    items: initialCartItems, // Initialize with localStorage data
};

export const cartSlice = createSlice({
    name: 'cart',
    initialState,
    reducers: {
        addToCart: (state, action) => {
            const existingItem = state.items.find(item => item.id === action.payload.id);
            if (existingItem) {
                toast.warning("This Item is already added", { position: "top-center" })
            } else {
                state.items.push({ ...action.payload, quantity: 1 });
                toast.success("Item added to cart Successfully", { position: "top-center" })
            }
        },
        removeFromCart: (state, action) => {
            state.items = state.items.filter(item => item.id !== action.payload);
        },
        increaseQuantity: (state, action) => {
            const item = state.items.find(item => item.id === action.payload);
            if (item) {
                item.quantity += 1;
            }
        },
        decreaseQuantity: (state, action) => {
            const item = state.items.find(item => item.id === action.payload);
            if (item && item.quantity > 1) {
                item.quantity -= 1;
            }
        },
        setCartItems: (state, action) => {
            state.items = action.payload;
        },
    },
});

export const { addToCart, removeFromCart, increaseQuantity, decreaseQuantity, setCartItems } = cartSlice.actions;

export default cartSlice.reducer;

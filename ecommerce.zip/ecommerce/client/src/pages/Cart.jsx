import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeFromCart, increaseQuantity, decreaseQuantity } from '../counter/cartSlice';
import { FaPlusCircle, FaMinusCircle } from "react-icons/fa";
import { loadStripe } from '@stripe/stripe-js';
import { useNavigate } from 'react-router-dom';

const stripePromise = loadStripe(''); // Replace with your Stripe public key

const Cart = () => {
    const cartItems = useSelector(state => state.cart.items); // Access cart from Redux state
    const dispatch = useDispatch();
    const [paymentMethod, setPaymentMethod] = useState('card');
    const navigate = useNavigate()

    // Save cart items to localStorage whenever they change
    useEffect(() => {
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
    }, [cartItems]); // Only run when cartItems changes

    const handleRemoveFromCart = (id) => {
        dispatch(removeFromCart(id));
    };

    const handleIncreaseQuantity = (id) => {
        dispatch(increaseQuantity(id));
    };

    const handleDecreaseQuantity = (id) => {
        dispatch(decreaseQuantity(id));
    };

    const totalPrice = cartItems.reduce((total, item) => {
        return total + (item.price * item.quantity);
    }, 0);


    const handleNavigate = () => {
        navigate('/shop')
    }
    

    const handlePayment = async () => {
        const stripe = await stripePromise;
        try {
            const response = await fetch('http://localhost:4242/create-checkout-session', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ items: cartItems, paymentMethod }), // Send selected payment method
            });
            
            const session = await response.json();

            if (response.ok) {
                await stripe.redirectToCheckout({ sessionId: session.id });
            } else {
                console.error('Error creating checkout session:', session.error);
                alert(session.error || 'Failed to create payment session');
            }
        } catch (error) {
            console.error("Payment error:", error);
        }
    };

    return (
        <div className='mx-32 my-10'>
            <h2 className='text-[30px] font-semibold font-poppins'>Your Cart</h2>
            {cartItems.length > 0 ? (
                <div className='flex flex-col gap-4'>
                    {cartItems.map(item => (
                        <div key={item.id} className='flex justify-between items-center border-b py-4'>
                            <div className='flex gap-4 '>
                                <img src={item.image} alt={item.title} width={50} height={50} />
                                <div>
                                    <h3>{item.title}</h3>
                                    <p>Price: ${item.price}</p>
                                    <p className='flex gap-3'>Quantity:
                                        <p className='flex items-center gap-2'>
                                            <span
                                                onClick={() => handleIncreaseQuantity(item.id)}
                                                className='text-[20px] font-semibold cursor-pointer'>
                                                <FaPlusCircle />
                                            </span>
                                            {item.quantity}
                                            <span
                                                className='text-[20px] font-semibold cursor-pointer'
                                                onClick={() => handleDecreaseQuantity(item.id)}>
                                                <FaMinusCircle />
                                            </span>
                                        </p>
                                    </p>
                                </div>
                            </div>
                            <button
                                onClick={() => handleRemoveFromCart(item.id)}
                                className='text-red-600 hover:underline'
                            >
                                Remove
                            </button>
                        </div>
                    ))}

                    {/* Total Price */}
                    <div className='flex justify-end text-[20px] font-semibold mt-5'>
                        <p>Total Price: ${totalPrice.toFixed(2)}</p>
                    </div>

                    {/* Payment Method Selection */}
            <div className="flex flex-col gap-4 mt-6">
                <h3 className="text-xl font-semibold text-gray-700">Select Payment Method</h3>
                <div className="flex items-center gap-6">
                    <label className="flex items-center gap-2">
                        <input
                            type="radio"
                            value="card"
                            checked={paymentMethod === 'card'}
                            onChange={() => setPaymentMethod('card')}
                            className="form-radio text-blue-600"
                        />
                        <span className="text-gray-700">Credit Card</span>
                    </label>
                    <label className="flex items-center gap-2">
                        <input
                            type="radio"
                            value="bank_account"
                            checked={paymentMethod === 'bank_account'}
                            onChange={() => setPaymentMethod('bank_account')}
                            className="form-radio text-blue-600"
                        />
                        <span className="text-gray-700">US Bank Account</span>
                    </label>
                </div>
            </div>
            <div>
                <button onClick={handlePayment} className='text-white text-[14px] font-medium font-poppins bg-blue-500 px-6 py-2 rounded-full'>Proceed to Pay</button>
            </div>

                </div>
            ) : (
                <div className="mt-5 flex flex-col items-center justify-center text-center py-10 bg-gray-50 rounded-lg shadow-lg">
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-16 h-16 text-gray-400 mb-4"
                >
                    <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M3 3h18M9 3v1.5a4.5 4.5 0 11-3 0V3m12 0v1.5a4.5 4.5 0 11-3 0V3m-9 9h12m-12 3h12"
                    />
                </svg>
                <h2 className="text-2xl font-semibold text-gray-700 mb-4">Your cart is empty</h2>
                <p className="text-gray-500 mb-6">
                    Looks like you haven't added anything to your cart yet.
                </p>
                <button onClick={handleNavigate} className="bg-blue-600 text-white px-6 py-3 rounded-full hover:bg-blue-700 transition duration-300 ease-in-out">
                    Continue Shopping
                </button>
            </div>

            )}
        </div>
    );
};

export default Cart;

























// import React, {useState, useEffect } from 'react';
// import { useSelector, useDispatch } from 'react-redux';
// import { removeFromCart, increaseQuantity, decreaseQuantity } from '../counter/cartSlice';
// import { FaPlusCircle, FaMinusCircle } from "react-icons/fa";


// const Cart = () => {
//     const cartItems = useSelector(state => state.cart.items); // Access cart from Redux state
//     const dispatch = useDispatch();
//     const [paymentMethod, setPaymentMethod] = useState('card');

//     // Save cart items to localStorage whenever they change
//     useEffect(() => {
//         localStorage.setItem('cartItems', JSON.stringify(cartItems));
//     }, [cartItems]); // Only run when cartItems changes

//     const handleRemoveFromCart = (id) => {
//         dispatch(removeFromCart(id));
//     };

//     const handleIncreaseQuantity = (id) => {
//         dispatch(increaseQuantity(id));
//     };

//     const handleDecreaseQuantity = (id) => {
//         dispatch(decreaseQuantity(id));
//     };

//     const totalPrice = cartItems.reduce((total, item) => {
//         return total + (item.price * item.quantity);
//     }, 0);

    
    


//     return (
//         <div className='mx-32 my-10'>
//             <h2 className='text-[30px] font-semibold font-poppins'>Your Cart</h2>
//             {cartItems.length > 0 ? (
//                 <div className='flex flex-col gap-4'>
//                     {cartItems.map(item => (
//                         <div key={item.id} className='flex justify-between items-center border-b py-4'>
//                             <div className='flex gap-4 '>
//                                 <img src={item.image} alt={item.title} width={50} height={50} />
//                                 <div>
//                                     <h3>{item.title}</h3>
//                                     <p>Price: ${item.price}</p>
//                                     <p className='flex gap-3'>Quantity:
//                                         <p className='flex items-center gap-2'>
//                                             <span
//                                                 onClick={() => handleIncreaseQuantity(item.id)}
//                                                 className='text-[20px] font-semibold cursor-pointer'>
//                                                 <FaPlusCircle />
//                                             </span>
//                                             {item.quantity}
//                                             <span
//                                                 className='text-[20px] font-semibold cursor-pointer'
//                                                 onClick={() => handleDecreaseQuantity(item.id)}>
//                                                 <FaMinusCircle />
//                                             </span>
//                                         </p>
//                                     </p>
//                                 </div>
//                             </div>
//                             <button
//                                 onClick={() => handleRemoveFromCart(item.id)}
//                                 className='text-red-600 hover:underline'
//                             >
//                                 Remove
//                             </button>
//                         </div>
//                     ))}
//                     {/* Total Price */}
//                     <div className='flex justify-end text-[20px] font-semibold mt-5'>
//                         <p>Total Price: ${totalPrice.toFixed(2)}</p>
//                     </div>
//                 </div>
//             ) : (
//                 <p>Your cart is empty.</p>
//             )}
//         </div>
//     );
// };

// export default Cart;

import React from 'react'
import Banner from '../components/home/Banner'
import EmailMe from '../components/home/EmailMe'
import NewlyArrived from '../components/home/NewlyArrived'
import LatestProducts from '../components/home/LatestProducts'
const Home = () => {
  return (
    <div>
        <Banner />
        <EmailMe/>
        <NewlyArrived />
        <LatestProducts />
    </div>
  )
}

export default Home
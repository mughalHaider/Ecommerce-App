import React from 'react'
import Products from '../components/home/Products'

const Shop = () => {
  return (
    <div className='my-10'>
        <Products/>
    </div>
  )
}

export default Shop
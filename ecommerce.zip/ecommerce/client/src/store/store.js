import { configureStore } from '@reduxjs/toolkit';
import cartReducer from '../counter/cartSlice'; // Adjust path as needed

export const store = configureStore({
  reducer: {
    cart: cartReducer, // Register cart slice under 'cart'
  },
});

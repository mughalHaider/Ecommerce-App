/** @type {import('tailwindcss').Config} */
import tailwindcssFilters from 'tailwindcss-filters';

export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        poppins: ['Poppins', 'sans-serif'],
        dancing: ['Dancing Script', 'cursive'],
      },
    },
  },
  plugins: [
    tailwindcssFilters, // Move plugin here
  ],
};
